library(shiny)
library(DT)
library(bslib)
library(knitr)
library(markdown)

insurancecols=read.csv("insurance.csv")
insurancecols=colnames(insurancecols)

options(scipen=999)
ohie= read.csv("ohie.plot.csv")
ohie <- ohie[,-1]

ohie$age <- as.numeric(ohie$age)
ohie$any_ed_visits <- as.factor(ohie$any_ed_visits)
ohie$any_ed_chronic_condition <- as.factor(ohie$any_ed_chronic_condition)
ohie$any_ed_injury <- as.factor(ohie$any_ed_injury)
ohie$any_ed_skin_condition <- as.factor(ohie$any_ed_skin_condition)
ohie$any_ed_abdominal_pain <- as.factor(ohie$any_ed_abdominal_pain )
ohie$any_ed_back_pain <- as.factor(ohie$any_ed_back_pain)
ohie$any_ed_heart_or_chest_pain <- as.factor(ohie$any_ed_heart_or_chest_pain)
ohie$any_ed_headache <- as.factor(ohie$any_ed_headache)
ohie$any_ed_depression <- as.factor(ohie$any_ed_depression )
ohie$charge_total <- as.numeric(ohie$charge_total) 
ohie$charge_food_assistance <-  as.numeric(ohie$charge_food_assistance)
ohie$charge_temporary_assistance <- as.numeric(ohie$charge_temporary_assistance)
ohie$preperiod_any_visits <- as.factor(ohie$preperiod_any_visits)
ohie$sex <- as.factor(ohie$sex)

ohiecols = ohie
ohiecols=colnames(ohiecols)


shinyUI(fluidPage(
  titlePanel("Preddly"),
    navbarPage("Healthier. Together.",
               theme = bs_theme(version = 4,
                                bg = "#FFFFFF",
                                fg = "#0A5192",
                                primary = "#85878C",
                                base_font = font_google("Oswald"),
                                bootswatch = "minty"
               ),
               tabPanel("Explore Expenses",
                        tabsetPanel(
                            tabPanel("Basic Needs",
                                     br(),
                                     sidebarLayout(
                                         sidebarPanel(
                                             selectInput(
                                                 "selectedColsyyy",
                                                 "y-axis",
                                                 choices=insurancecols,
                                                 selected=insurancecols[3]
                                             ),
                                             selectInput(
                                                 "selectedColsxxx",
                                                 "x-axis",
                                                 choices=insurancecols,
                                                 selected=insurancecols[7]
                                             ),
                                             sliderInput("ageInputtt", "Age", min=18, max=70,
                                                         value=c(18,70)
                                             ),
                                             sliderInput("bmiInputtt", "BMI", min=10, max=50,
                                                         value=c(10,50)
                                             ),
                                             sliderInput("childrenInputtt", "Children", min=0, max=8,
                                                         value=c(0,8)
                                             ),
                                             sliderInput("expensesInputtt", "Expenses", min=0, max=70000,
                                                         value=c(0,70000)
                                             ),
                                             checkboxGroupInput("genderInputtt", "Sex",
                                                                choiceNames = list("Female", "Male"),
                                                                choiceValues = list("male", "female"),
                                                                selected=list("male","female")
                                             )),
                                         mainPanel(
                                             plotOutput("plot3"),
                                             plotOutput("plot4"),
                                             br(),br()
                                         )
                                     )
                            ),
                                       tabPanel("Specific Needs",
                                                br(),
                                                sidebarLayout(
                                                  sidebarPanel(
                                                    selectInput(
                                                      "selectedCooly",
                                                      "y-axis",
                                                      choices=ohiecols,
                                                      selected= ohiecols[13]
                                                    ),
                                                    selectInput(
                                                      "selectedCoolx",
                                                      "x-axis",
                                                      choices=ohiecols,
                                                      selected=ohiecols[2]
                                                    ),
                                                    sliderInput("ageINPUT", "Age", min=18, max=70,
                                                                value=c(18,70)
                                                    ),
                                                    sliderInput("expensesINPUT", "Expenses", min=0, max=400000,
                                                                value=c(0,400000)
                                                    ),
                                                    sliderInput("cfoodINPUT", "Amount of dollar value in SNAP* food assistance received", min=0, max=80000,
                                                                value=c(0,80000)
                                                    ),
                                                    sliderInput("ctemporaryINPUT", "Amount of dollar value TANF** assistance recieved", min=0, max=70000,
                                                                value=c(0,70000)
                                                    ),
                                                    checkboxGroupInput("sexINPUT", "Sex",
                                                                       choiceNames = list("Female", "Male"),
                                                                       choiceValues = list("Female", "Male"),
                                                                       selected=list("Female","Male")
                                                    ),
                                                    checkboxGroupInput("preperiodINPUT", "Any doctors visits",
                                                                       choiceNames = list("No", "Yes"),
                                                                       choiceValues = list(0,1),
                                                                       selected=list(0,1)
                                                    ),
                                                    checkboxGroupInput("visitsINPUT", "Any emergency department visits",
                                                                       choiceNames = list("No", "Yes"),
                                                                       choiceValues = list("FALSE", "TRUE"),
                                                                       selected=list("FALSE","TRUE")
                                                    ),
                                                    checkboxGroupInput("chronicINPUT", "Any emergency department visits for a chronic decision",
                                                                       choiceNames = list("No", "Yes"),
                                                                       choiceValues = list("FALSE", "TRUE"),
                                                                       selected=list("FALSE","TRUE")
                                                    ),
                                                    checkboxGroupInput("injuryINPUT", "Any emergency department visits for a injury condition",
                                                                       choiceNames = list("No", "Yes"),
                                                                       choiceValues = list("FALSE", "TRUE"),
                                                                       selected=list("FALSE","TRUE")
                                                    ),
                                                    checkboxGroupInput("skinINPUT", "Any emergency department visits for skin condition",
                                                                       choiceNames = list("No", "Yes"),
                                                                       choiceValues = list("FALSE", "TRUE"),
                                                                       selected=list("FALSE","TRUE")
                                                    ),
                                                    checkboxGroupInput("abdominalINPUT", "Any emergency department visits for abdominal pain",
                                                                       choiceNames = list("No", "Yes"),
                                                                       choiceValues = list("FALSE", "TRUE"),
                                                                       selected=list("FALSE","TRUE")
                                                    ),
                                                    checkboxGroupInput("backINPUT", "Any emergency department visits for back pain",
                                                                       choiceNames = list("No", "Yes"),
                                                                       choiceValues = list("FALSE", "TRUE"),
                                                                       selected=list("FALSE","TRUE")
                                                    ),
                                                    checkboxGroupInput("heartINPUT", "Any emergency department visits for hear or chest pain",
                                                                       choiceNames = list("No", "Yes"),
                                                                       choiceValues = list("FALSE", "TRUE"),
                                                                       selected=list("FALSE","TRUE")
                                                    ),
                                                    checkboxGroupInput("headacheINPUT", "Any emergency department visits for hear a headache",
                                                                       choiceNames = list("No", "Yes"),
                                                                       choiceValues = list("FALSE", "TRUE"),
                                                                       selected=list("FALSE","TRUE")
                                                    ),
                                                    checkboxGroupInput("depressionINPUT", "Any emergency department visits for depression",
                                                                       choiceNames = list("No", "Yes"),
                                                                       choiceValues = list("FALSE", "TRUE"),
                                                                       selected=list("FALSE","TRUE")
                                                    )),
                                                  mainPanel(
                                                    p(code("*supplemental nutrition assistance programm")),
                                                    p(code("**Temporary Assistance for Needy Families")),
                                                    plotOutput("pl"),
                                                    br(),br(),
                                                    plotOutput("pl1"),
                                                    br(),br(),
                                                    plotOutput("pl2"),
                                                    br(),br()
                                                  )
                                                )
                                       )
                                     
                            ,
                            tabPanel("Search ",
                                     verticalLayout(
                                         mainPanel(
                                             dataTableOutput("results")
                                         )
                                     )
                            ))),
               tabPanel("Predict YOUR Expenses ",
                        tabsetPanel(
                          tabPanel("Basic Model",
                                     br(),
                                     sidebarLayout(
                                         sidebarPanel(
                                             radioButtons("gender_Input", "Choose your sex", 
                                                          c("Male" = "male",
                                                            "Female" = "female")
                                             ),
                                             numericInput("age_Input", "Enter your age", min=0, max=70,
                                                          value=c(0)
                                             ),
                                             numericInput("weights_Input", "Enter your weights (kg)", min=40, max=150,
                                                          value=c(0)
                                             ),
                                             numericInput("heights_Input", "Enter your heights (cm)", min=130, max=220,
                                                          value=c(0)
                                             ),
                                             numericInput("children_Input", "How many children do you have", min = 0, max = 10,
                                                          value = c(1)
                                             ),
                                             radioButtons("smoker_Input", "Do you smoke?", 
                                                          c("Yes" = "yes",
                                                            "No" = "no")
                                             ),
                                             selectInput("region_Input", "Region", c("northwest", "northeast", "southeast", "southwest")
                                             )),
                                         mainPanel(
                                           h1(" Your Prediction in USD"),
                                             p(strong(h3(textOutput("fit")))),
                                             tableOutput("result"))
                                         
                                     ))
                        ,
                        tabPanel("Specific Model",
                                 br(),
                                 sidebarLayout(
                                   sidebarPanel(
                                     numericInput("ageINPUTt", "Enter your age", min=0, max=70,
                                                  value=c(0)
                                     ),
                                     numericInput("cfoodINPUTt", "Amount of dollar value SNAP* assistance recieved", min=0, max=90000,
                                                  value=c(0)
                                     ),
                                     numericInput("ctemporaryINPUTt", "Amount of dollar value TANF** assistance recieved", min=0, max=90000,
                                                  value=c(0)
                                     ),
                                     selectInput("sexINPUTt", "Sex",
                                                 choices = c("Female" = 0, "Male" = 1)
                                                 
                                     ),
                                     radioButtons("preperiodINPUTt", "Any doctor visits",
                                                  c("Yes" = 1,
                                                    "No" = 0), selected = 0
                                     ),
                                     radioButtons("visitsINPUTt", "Any emergency department visits",
                                                  c("Yes" = 1,
                                                    "No" = 0), selected = 0
                                     ),
                                     radioButtons("chronicINPUTt", "Any emergency department visits for a chronic decision",
                                                  c("Yes" = 1,
                                                    "No" = 0), selected = 0
                                     ),
                                     radioButtons("injuryINPUTt", "Any emergency department visits for a injury condition",
                                                  c("Yes" = 1,
                                                    "No" = 0), selected = 0
                                     ),
                                     radioButtons("skinINPUTt", "Any emergency department visits for skin condition",
                                                  c("Yes" = 1,
                                                    "No" = 0), selected = 0
                                     ),
                                     radioButtons("abdominalINPUTt", "Any emergency department visits for abdominal pain",
                                                  c("Yes" = 1,
                                                    "No" = 0), selected = 0
                                     ),
                                     radioButtons("backINPUTt", "Any emergency department visits for back pain",
                                                  c("Yes" = 1,
                                                    "No" = 0), selected = 0
                                     ),
                                     radioButtons("heartINPUTt", "Any emergency department visits for hear or chest pain",
                                                  c("Yes" = 1,
                                                    "No" = 0), selected = 0
                                     ),
                                     radioButtons("headacheINPUTt", "Any emergency department visits for hear a headache",
                                                  c("Yes" = 1,
                                                    "No" = 0), selected = 0
                                     ),
                                     radioButtons("depressionINPUTt", "Any emergency department visits for depression",
                                                  c("Yes" = 1,
                                                    "No" = 0), selected = 0
                                     ),
                                     actionButton("submit","Predict")),
                                   mainPanel(
                                     p(code("* supplemental nutrition assistance programm")),
                                     p(code("** Temporary Assistance for Needy Families")),
                                     h1("Your Prediction in USD"),
                                     p(strong(h3(textOutput("fit1"))))
                                     #tableOutput("res"))#
                        
                        
               ))))),
               tabPanel("Optimize YOUR Life",
                        navlistPanel(
                          tabPanel("Register",
                                   h6("Please complete the registration to save up your predictions and receive our newsletter."),
                                   br(),
                                   verticalLayout(
                                     sidebarPanel(
                                       radioButtons("Saluations_Input", "Dear", 
                                                    c("Mr" = "yes",
                                                      "Ms" = "no")
                                       ),
                                       textInput("Firstname_Input", "First name",
                                                 value = ""
                                       ),
                                       textInput("Surname_Input", "Surname",
                                                 value = ""
                                       ),
                                       numericInput("zip_Input", "ZIP", min = 00601, max = 99950,
                                                    value = ""
                                       ),
                                       textInput("Street_Input", "Street",
                                                 value = ""
                                       ),
                                       numericInput("Number_Input", "Number", min = 1, max = 1000,
                                                    value = ""
                                       ),
                                       textInput("email_Input", "E-Mail",
                                                 value = ""
                                       ),
                                       numericInput("phone_Input", "Phone", min = 10000000, max = 100000000,
                                                    value = ""),
                                       passwordInput("password", "Password"),
                                       actionButton("go", "Register"),
                                       verbatimTextOutput("value")
                                     ))
                          ), 
                        tabPanel("Comparison",
                                   splitLayout(
                                   sidebarPanel(width = 10,
                                     p(strong(h3("Profil 1"))),
                                     radioButtons("gender.Input", "Choose your sex", 
                                                  c("male" = "male",
                                                    "female" = "female")
                                     ),
                                     numericInput("age.Input", "Enter your age", min=0, max=90,
                                                  value=c(0)
                                     ),
                                     numericInput("weights.Input", "Enter your weights (kg)", min=40, max=150,
                                                  value=c(0)
                                     ),
                                     numericInput("heights.Input", "Enter your heights (cm)", min=130, max=220,
                                                  value=c(0)
                                     ),
                                     numericInput("children.Input", "Children", min = 0, max = 10,
                                                  value = c(0)
                                     ),
                                     radioButtons("smoker.Input", "Do you smoke?", 
                                                  c("Yes" = "yes",
                                                    "No" = "no")
                                     ),
                                     selectInput("region.Input", "Region", c("northwest", "northeast", "southeast", "southwest")
                                     )),

                                   sidebarPanel(width = 10,
                                     p(strong(h3("Profil 2"))),
                                     radioButtons("gender__Input", "Choose your sex", 
                                                  c("male" = "male",
                                                    "female" = "female")
                                     ),
                                     numericInput("age__Input", "Enter your age", min=0, max=90,
                                                  value=c(0)
                                     ),
                                     numericInput("weights__Input", "Enter your weights (kg)", min=40, max=150,
                                                  value=c(0)
                                     ),
                                     numericInput("heights__Input", "Enter your heights (cm)", min=130, max=220,
                                                  value=c(0)
                                     ),
                                     numericInput("children__Input", "Children", min = 0, max = 10,
                                                  value = c(0)
                                     ),
                                     radioButtons("smoker__Input", "Do you smoke?", 
                                                  c("Yes" = "yes",
                                                    "No" = "no")),
                                     selectInput("region__Input", "Region", c("northwest", "northeast", "southeast", "southwest")
                                   ))

                                     
                                   )),
                        
                        tabPanel("Result",
                                   splitLayout(
                                     mainPanel(
                                       h4(" Profil 1 Prediction in USD"),
                                       p(strong(h1(textOutput("fit.lm.1")))),
                                       br(), br(), br(),
                                       p(strong(h4(textOutput("lost")))),
                                       p(strong(h1(textOutput("gain"))))),
                                 
                                     mainPanel(
                                       h4("Profil 2 Prediction in USD"),
                                       p(strong(h1(textOutput("fit.lm.2")))),
                                       br(),br(),br(),br(),br(),br(),br(),br(), br(),br(),br(),br(),br(),br(),br(),br())
                                      
                        
                                     )),
                        
                          tabPanel("Recommendations for a healthier life",
                                   flowLayout(
                                       titlePanel("Partners"), 
                                           br(),
                                           tags$a(href="https://blog.fitbit.com/", img(src='fitbit-logo2.png', height = "50%", width = "50%", align = "center")),
                                           br(),
                                           tags$a(href="https://www.eatingwell.com/recipes/", img(src = 'eatingwell-logo.jpg', height = "50%", width = "50%", align = "center")
                                           ),
                                           br(),
                                           tags$a(href="https://smokefreeapp.com/",img(src='smoke-logo.png', height = "50%", width = "50%", align = "center")
                                           ),
                                           br(),
                                           tags$a(href="https://kidshealth.org/", img(src = 'kidshealth-logo.jpg' , height = "50%", width = "50%", align = "center")
                                           ),
                                           br(),
                                           tags$a(href="https://www.gaiam.com/", img(src = 'gaiam-logo.jpg' , height = "50%", width = "50%", align = "center")
                                           ),
                                           br(),
                                           tags$a(href="https://www.headspace.com/mindfulness/mindful-eating", img(src = 'headspace-logo.jpg' , height = "50%", width = "50%", align = "center")
                                           ),
                                           br(),
                                           tags$a(href= "https://www.24hourfitness.com/" , img(src = 'zok.png' , height = "50%", width = "50%", align = "center")
                                           )      
                                     ))))

                                                )
                                                ))
                                            


               
            
  